package unicam.cs.ids.AbbateMarcellini;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UtentiController {
	private UtenteServiceDB utenteService;
	
	@GetMapping("/utenti")
	public List<Utente> getAllUtenti() {
		return utenteService.getAllUtenti();
	}
	
	@GetMapping("/utenti/(id)")
	public Utente getUtente(@PathVariable Long id) {
		return utenteService.getUtente(id);
	}
	
	@RequestMapping(value = "/utenti", method = RequestMethod.POST)
	public void addUtente(@RequestBody Utente utente) {
		utenteService.addUtente(utente);
	}
	
	@RequestMapping(value = "/utenti", method = RequestMethod.PUT)
	public void updateUtente(@PathVariable Long id, @RequestBody Utente utente) {
		utenteService.updateUtente(id, utente);
	}
	
	@RequestMapping(value = "/utenti", method = RequestMethod.DELETE)
	public void deleteUtente(@PathVariable Long id) {
		utenteService.deleteUtente(id);
	}

}
