package unicam.cs.ids.AbbateMarcellini;

import java.time.LocalDate;

public class Pubblicato implements Processa{
	public void processa(Contenuto cont) {
		System.out.println("Stato: Pubblicato il "+LocalDate.now());
	}
}