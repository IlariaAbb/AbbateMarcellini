package unicam.cs.ids.AbbateMarcellini;

public class Contenuto implements Crea, Processa{
	Ruolo Autore;
	String Titolo;
	String Descrizione;
	
	public void create(Ruolo Autore, String Titolo, String Descrizione) {
		this.Autore = Autore;
		this.Titolo = Titolo;
		this.Descrizione = Descrizione;
	}

	public void setAutore(Ruolo Autore) {
		this.Autore = Autore;
	}
	
	public void setTitolo(String Titolo) {
		this.Titolo = Titolo;
	}
	
	public void setDescrizione(String Descrizione) {
		this.Descrizione = Descrizione;
	}

	public void create(Contenuto cont) {
		// TODO Auto-generated method stub
	}
	
	public void processa(Contenuto cont) {
		// TODO Auto-generated method stub
	}
	
	public Processa currentState;
	
	public Contenuto() {
		this.currentState = new Caricato();
	}
	
	public void setState(Processa state) {
		this.currentState = state;
	}

	protected void finalize() {
	    System.out.println("Il contenuto è stato rimosso.");
	  }




}
