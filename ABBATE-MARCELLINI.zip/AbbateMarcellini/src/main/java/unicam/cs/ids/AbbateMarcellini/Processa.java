package unicam.cs.ids.AbbateMarcellini;

public interface Processa {
	void processa (Contenuto cont);
	}
