package unicam.cs.ids.AbbateMarcellini;

import java.util.List;

public interface UtenteService {
	public List<Utente> getAllUtenti();
	public Utente getUtente(Long id);
	public void addUtente(Utente utente);
	public void updateUtente(Long id, Utente utente);
	public void deleteUtente(Long id);

}
