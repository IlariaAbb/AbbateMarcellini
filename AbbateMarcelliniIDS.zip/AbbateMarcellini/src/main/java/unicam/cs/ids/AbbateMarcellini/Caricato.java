package unicam.cs.ids.AbbateMarcellini;

public class Caricato implements Processa {
	public void processa(Contenuto cont) {
		System.out.println("Stato: Contenuto correttamente caricato");
		cont.setState(new Attesa());
	}
}