package unicam.cs.ids.AbbateMarcellini;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AbbateMarcelliniApplication {

	public static void main(String[] args) {
		SpringApplication.run(AbbateMarcelliniApplication.class, args);
	}

}
