package unicam.cs.ids.AbbateMarcellini;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AbbateMarcelliniApplication {

	public static void main(String[] args) {
		SpringApplication.run(AbbateMarcelliniApplication.class, args);

	Utente utente1 = new Utente(null, "ilaria_a", "io@email.it", "PassWord", null, "Matelica");
	utente1.getId();
	utente1.getNome_utente();
	utente1.getEmail();
	utente1.getPassword();
	utente1.getDataNascita();
	utente1.getComuneResidenza();
		
	Contenuto contenuto1 = new Contenuto();
	contenuto1.setAutore(enum.Curatore);
	contenuto1.setTitolo("Apertura piattaforma");
	
	
	}
}
