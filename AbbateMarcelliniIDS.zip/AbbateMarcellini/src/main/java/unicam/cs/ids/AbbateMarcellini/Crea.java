package unicam.cs.ids.AbbateMarcellini;

public interface Crea {
	void create (Contenuto cont);
}
