package unicam.cs.ids.AbbateMarcellini;

public abstract class Contenuto implements Crea, Processa{
	Ruolo Autore;
	String Titolo;
	String Descrizione;
	
	public void create(Ruolo Autore, String Titolo, String Descrizione) {
		this.Autore = Autore;
		this.Titolo = Titolo;
		this.Descrizione = Descrizione;
	}
	
	public Processa currentState;
	
	public Contenuto() {
		this.currentState = new Caricato();
	}
	
	public void setState(Processa state) {
		this.currentState = state;
	}

	protected void finalize() {
	    System.out.println("Il contenuto è stato rimosso.");
	  }
}
