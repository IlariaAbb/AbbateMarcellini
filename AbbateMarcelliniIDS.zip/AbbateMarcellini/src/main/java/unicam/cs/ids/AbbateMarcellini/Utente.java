package unicam.cs.ids.AbbateMarcellini;

import java.util.Calendar;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Entity
@Table(name="utente")
public class Utente {
	@Id
	@GeneratedValue
	private Long id;
	private String nome_utente;
	private String email;
	private String password;
	private Calendar dataNascita;
	private String comuneResidenza;
	
	public Utente(Long id, String nome_utente, String email, String password, Calendar dataNascita, String comuneResidenza) {
		this.id = id;
		this.nome_utente = nome_utente;
		this.password = password;
		this.email = email;
		this.dataNascita = dataNascita;
		this.comuneResidenza = comuneResidenza;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNome_utente() {
		return nome_utente;
	}

	public void setNome_utente(String nome_utente) {
		this.nome_utente = nome_utente;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Calendar getDataNascita() {
		return dataNascita;
	}

	public void setDataNascita(Calendar dataNascita) {
		this.dataNascita = dataNascita;
	}

	public String getComuneResidenza() {
		return comuneResidenza;
	}

	public void setComuneResidenza(String comuneResidenza) {
		this.comuneResidenza = comuneResidenza;
	}

}

	


	
