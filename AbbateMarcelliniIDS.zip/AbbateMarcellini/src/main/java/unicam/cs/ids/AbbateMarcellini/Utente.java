package unicam.cs.ids.AbbateMarcellini;

import java.util.Calendar;

public class Utente {
	private int id;
	private String nome_utente;
	private String email;
	private String password;
	private Calendar dataNascita;
	private String comuneResidenza;
	
	public Utente(int id, String nome_utente, String email, String password, Calendar dataNascita, String comuneResidenza) {
		this.setId(this.hashCode());
		this.setNome_utente(nome_utente);
		this.setPassword(password);
		this.setEmail(email);
		this.setDataNascita(dataNascita);
		this.setComuneResidenza(comuneResidenza);
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome_utente() {
		return nome_utente;
	}

	public void setNome_utente(String nome_utente) {
		this.nome_utente = nome_utente;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Calendar getDataNascita() {
		return dataNascita;
	}

	public void setDataNascita(Calendar dataNascita) {
		this.dataNascita = dataNascita;
	}

	public String getComuneResidenza() {
		return comuneResidenza;
	}

	public void setComuneResidenza(String comuneResidenza) {
		this.comuneResidenza = comuneResidenza;
	}

}
