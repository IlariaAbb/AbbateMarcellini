package unicam.cs.ids.AbbateMarcellini;

public class Attesa implements Processa {
	public void processa(Contenuto cont) {
		System.out.println("Stato: In attesa di verifica");
		cont.setState(new Pubblicato());
	}
}